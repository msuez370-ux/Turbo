import { defineConfig } from 'vite';

export default defineConfig({
  root: 'client',
  build: { outDir: '../dist', emptyOutDir: true, chunkSizeWarningLimit: 1500 },
  server: {
    port: 5173,
    fs: { allow: ['..'] },
    // En développement, le jeu (5173) parle au serveur (3000)
    proxy: { '/socket.io': { target: 'http://localhost:3000', ws: true } },
  },
});
