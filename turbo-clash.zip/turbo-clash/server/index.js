// Serveur de jeu : salons, course, bonus, missiles, mines, dégâts.
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { Server } from 'socket.io';
import { LAPS, SAMPLES, gridSlot, pickupLayout } from '../shared/track.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 8;
const TICK = 50; // ms (20 fois par seconde)

const app = express();
app.use(express.static(path.join(__dirname, '..', 'dist')));
app.get('/health', (_req, res) => res.send('ok'));
app.use((_req, res) => res.sendFile(path.join(__dirname, '..', 'dist', 'index.html')));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const COLORS = ['#ff2e63', '#08d9d6', '#f9ed69', '#7cff4f', '#b967ff', '#ff9a3c', '#ffffff', '#3d7bff'];
const rooms = new Map();

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c;
  do { c = Array.from({ length: 5 }, () => chars[Math.floor(Math.random() * chars.length)]).join(''); }
  while (rooms.has(c));
  return c;
}

function newRoom(code) {
  const room = {
    code, state: 'lobby', hostId: null, players: new Map(),
    pickups: pickupLayout().map(p => ({ ...p, active: true, respawnAt: 0 })),
    projectiles: [], nextProj: 1, startAt: 0, finishOrder: [], feed: [],
  };
  rooms.set(code, room);
  return room;
}

function publicPlayers(room) {
  return [...room.players.values()].map(p => ({
    id: p.id, name: p.name, color: p.color, slot: p.slot, ready: p.ready,
    hp: p.hp, takedowns: p.takedowns, wrecks: p.wrecks, finished: p.finishTime ?? null,
  }));
}

function lobbyUpdate(room) {
  io.to(room.code).emit('lobby', { code: room.code, state: room.state, hostId: room.hostId, players: publicPlayers(room), laps: LAPS });
}

function addFeed(room, text) {
  io.to(room.code).emit('feed', text);
}

function damage(room, victim, amount, attacker, cause) {
  if (!victim || victim.destroyed || victim.finishTime != null || room.state !== 'racing') return;
  victim.hp = Math.max(0, victim.hp - amount);
  io.to(victim.id).emit('damaged', { hp: victim.hp, by: attacker?.id ?? null });
  if (victim.hp <= 0) {
    victim.destroyed = true;
    victim.wrecks++;
    if (attacker && attacker !== victim) attacker.takedowns++;
    io.to(room.code).emit('wrecked', { id: victim.id, by: attacker?.id ?? null, x: victim.x, z: victim.z });
    addFeed(room, attacker && attacker !== victim
      ? `💥 ${attacker.name} a détruit ${victim.name} (${cause})`
      : `💥 ${victim.name} est hors course`);
    setTimeout(() => {
      if (!room.players.has(victim.id)) return;
      victim.hp = 100; victim.destroyed = false;
      io.to(room.code).emit('respawned', { id: victim.id });
    }, 3000);
  }
}

function startCountdown(room) {
  room.state = 'countdown';
  room.finishOrder = [];
  room.projectiles = [];
  room.pickups.forEach(p => { p.active = true; });
  let slot = 0;
  for (const p of room.players.values()) {
    p.slot = slot++; p.hp = 100; p.destroyed = false; p.finishTime = null;
    p.lap = 0; p.idx = SAMPLES - 12; p.takedowns = 0; p.wrecks = 0; p.weapon = null;
    const g = gridSlot(p.slot);
    p.x = g.x; p.z = g.z; p.h = g.heading;
  }
  room.startAt = Date.now() + 4000;
  lobbyUpdate(room);
  io.to(room.code).emit('countdown', { startAt: room.startAt, serverNow: Date.now(), players: publicPlayers(room) });
  setTimeout(() => { if (room.state === 'countdown') room.state = 'racing'; }, 4000);
}

function finishRace(room) {
  room.state = 'finished';
  const results = [...room.players.values()]
    .sort((a, b) => (a.finishTime ?? Infinity) - (b.finishTime ?? Infinity) || b.lap * SAMPLES + b.idx - (a.lap * SAMPLES + a.idx))
    .map((p, i) => ({ rank: i + 1, name: p.name, color: p.color, time: p.finishTime, takedowns: p.takedowns, wrecks: p.wrecks }));
  io.to(room.code).emit('results', results);
  setTimeout(() => {
    if (!rooms.has(room.code)) return;
    room.state = 'lobby';
    room.players.forEach(p => { p.ready = false; });
    lobbyUpdate(room);
  }, 8000);
}

io.on('connection', (socket) => {
  let room = null;
  let me = null;

  socket.on('create', ({ name }, ack) => {
    const r = newRoom(makeCode());
    ack?.({ code: r.code });
  });

  socket.on('join', ({ code, name }, ack) => {
    code = String(code || '').toUpperCase().trim();
    const r = rooms.get(code);
    if (!r) return ack?.({ error: "Cette course n'existe plus. Crée-en une nouvelle." });
    if (r.players.size >= MAX_PLAYERS) return ack?.({ error: 'La course est pleine (8 joueurs max).' });
    if (r.state !== 'lobby') return ack?.({ error: 'La course a déjà commencé. Attends la fin de la manche.' });
    room = r;
    const used = new Set([...r.players.values()].map(p => p.color));
    me = {
      id: socket.id, name: String(name || 'Pilote').slice(0, 16), color: COLORS.find(c => !used.has(c)) || '#ffffff',
      slot: r.players.size, ready: false, hp: 100, destroyed: false, takedowns: 0, wrecks: 0,
      x: 0, z: 0, h: 0, s: 0, lap: 0, idx: 0, finishTime: null, weapon: null, lastRam: 0,
    };
    r.players.set(socket.id, me);
    if (!r.hostId) r.hostId = socket.id;
    socket.join(code);
    ack?.({ ok: true, id: socket.id, code, pickups: r.pickups });
    lobbyUpdate(r);
    addFeed(r, `🏁 ${me.name} a rejoint la course`);
  });

  socket.on('ready', (v) => { if (me && room) { me.ready = !!v; lobbyUpdate(room); } });

  socket.on('start', () => {
    if (!room || socket.id !== room.hostId || room.state !== 'lobby') return;
    startCountdown(room);
  });

  // Position envoyée par le navigateur du joueur
  socket.on('state', (st) => {
    if (!me || !room || me.destroyed) return;
    if (typeof st?.x !== 'number' || typeof st?.z !== 'number') return;
    me.x = st.x; me.z = st.z; me.h = +st.h || 0; me.s = +st.s || 0;
    me.lap = st.lap | 0; me.idx = st.idx | 0; me.nitro = !!st.n;
  });

  socket.on('lapDone', ({ lap }) => {
    if (!me || !room || room.state !== 'racing' || me.finishTime != null) return;
    if (lap >= LAPS) {
      me.finishTime = Date.now() - room.startAt;
      room.finishOrder.push(me.id);
      addFeed(room, `🏆 ${me.name} termine ${room.finishOrder.length === 1 ? '1er' : room.finishOrder.length + 'e'}`);
      const allDone = [...room.players.values()].every(p => p.finishTime != null);
      if (allDone) finishRace(room);
      else if (room.finishOrder.length === 1) {
        // 30 secondes pour les autres après le premier arrivé
        setTimeout(() => { if (room.state === 'racing') finishRace(room); }, 30000);
      }
    }
  });

  socket.on('pickup', (id, ack) => {
    if (!me || !room || room.state !== 'racing' || me.destroyed) return;
    const p = room.pickups[id];
    if (!p || !p.active) return;
    if ((p.x - me.x) ** 2 + (p.z - me.z) ** 2 > 16 ** 2) return; // trop loin : refusé
    p.active = false;
    p.respawnAt = Date.now() + 8000;
    io.to(room.code).emit('pickupState', { id, active: false });
    if (p.type === 'nitro') {
      socket.emit('gotNitro', 45);
    } else {
      me.weapon = Math.random() < 0.55 ? 'missile' : 'mine';
      socket.emit('gotWeapon', me.weapon);
    }
  });

  socket.on('fire', () => {
    if (!me || !room || room.state !== 'racing' || !me.weapon || me.destroyed) return;
    const dirX = Math.sin(me.h), dirZ = Math.cos(me.h);
    if (me.weapon === 'missile') {
      room.projectiles.push({
        id: room.nextProj++, kind: 'missile', owner: me.id,
        x: me.x + dirX * 4, z: me.z + dirZ * 4,
        vx: dirX * Math.max(110, me.s + 60), vz: dirZ * Math.max(110, me.s + 60), life: 3.5,
      });
    } else {
      room.projectiles.push({
        id: room.nextProj++, kind: 'mine', owner: me.id,
        x: me.x - dirX * 5, z: me.z - dirZ * 5, vx: 0, vz: 0, life: 40, armIn: 0.6,
      });
    }
    me.weapon = null;
    socket.emit('gotWeapon', null);
  });

  // Choc entre deux voitures, signalé par le pilote qui percute
  socket.on('ram', ({ target, power }) => {
    if (!me || !room || room.state !== 'racing') return;
    const victim = room.players.get(target);
    if (!victim || victim.destroyed) return;
    const now = Date.now();
    if (now - me.lastRam < 400) return;
    if ((victim.x - me.x) ** 2 + (victim.z - me.z) ** 2 > 9 ** 2) return;
    me.lastRam = now;
    const p = Math.max(0, Math.min(60, +power || 0));
    const dmg = Math.round(p * 0.9 + (me.nitro ? 15 : 0));
    if (dmg < 4) return;
    io.to(victim.id).emit('bumped', { from: me.id, power: p, dx: victim.x - me.x, dz: victim.z - me.z });
    damage(room, victim, dmg, me, me.nitro ? 'percuté en nitro' : 'percuté');
  });

  socket.on('disconnect', () => {
    if (!room || !me) return;
    room.players.delete(socket.id);
    addFeed(room, `👋 ${me.name} a quitté la course`);
    if (room.players.size === 0) { rooms.delete(room.code); return; }
    if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
    lobbyUpdate(room);
    if (room.state === 'racing' && [...room.players.values()].every(p => p.finishTime != null)) finishRace(room);
  });
});

// Boucle du serveur : projectiles, bonus, envoi des positions
setInterval(() => {
  const now = Date.now();
  const dt = TICK / 1000;
  for (const room of rooms.values()) {
    if (room.state !== 'racing' && room.state !== 'countdown') continue;

    for (const p of room.pickups) {
      if (!p.active && now > p.respawnAt) {
        p.active = true;
        io.to(room.code).emit('pickupState', { id: p.id, active: true });
      }
    }

    const players = [...room.players.values()];
    room.projectiles = room.projectiles.filter(pr => {
      pr.life -= dt;
      if (pr.life <= 0) return false;
      if (pr.kind === 'missile') {
        // Guidage léger vers l'adversaire le plus proche devant le missile
        let target = null, best = 90 ** 2;
        for (const pl of players) {
          if (pl.id === pr.owner || pl.destroyed || pl.finishTime != null) continue;
          const dx = pl.x - pr.x, dz = pl.z - pr.z, d = dx * dx + dz * dz;
          const speed = Math.hypot(pr.vx, pr.vz);
          if (d < best && (dx * pr.vx + dz * pr.vz) / speed > Math.sqrt(d) * 0.5) { best = d; target = pl; }
        }
        if (target) {
          const sp = Math.hypot(pr.vx, pr.vz);
          const dx = target.x - pr.x, dz = target.z - pr.z, l = Math.hypot(dx, dz) || 1;
          pr.vx += (dx / l * sp - pr.vx) * 0.12;
          pr.vz += (dz / l * sp - pr.vz) * 0.12;
        }
        pr.x += pr.vx * dt; pr.z += pr.vz * dt;
      } else if (pr.armIn > 0) {
        pr.armIn -= dt;
        return true;
      }
      const radius = pr.kind === 'missile' ? 4 : 3.2;
      for (const pl of players) {
        if (pl.destroyed || pl.finishTime != null) continue;
        if (pr.kind === 'missile' && pl.id === pr.owner) continue;
        if ((pl.x - pr.x) ** 2 + (pl.z - pr.z) ** 2 < radius ** 2) {
          const owner = room.players.get(pr.owner);
          io.to(room.code).emit('boom', { x: pr.x, z: pr.z, kind: pr.kind });
          io.to(pl.id).emit('bumped', { from: pr.owner, power: 45, dx: pl.x - pr.x, dz: pl.z - pr.z, lift: true });
          damage(room, pl, pr.kind === 'missile' ? 65 : 55, owner, pr.kind === 'missile' ? 'missile' : 'mine');
          return false;
        }
      }
      return true;
    });

    io.to(room.code).emit('snap', {
      t: now,
      p: players.map(p => [p.id, +p.x.toFixed(2), +p.z.toFixed(2), +p.h.toFixed(3), +p.s.toFixed(1), p.lap, p.idx, p.destroyed ? 1 : 0, p.nitro ? 1 : 0, p.hp]),
      pr: room.projectiles.map(pr => [pr.id, pr.kind, +pr.x.toFixed(1), +pr.z.toFixed(1), +Math.atan2(pr.vx, pr.vz).toFixed(2), pr.armIn > 0 ? 0 : 1]),
    });
  }
}, TICK);

server.listen(PORT, () => console.log(`Turbo Clash prêt sur http://localhost:${PORT}`));
