# Turbo Clash

Jeu de course multijoueur en ligne, dans le navigateur.
Tu crées une course, tu envoies le lien par email, ton ami clique et vous jouez ensemble. Rien à installer.

- Jusqu'à 8 joueurs par course, 3 tours
- Nitro (Maj) à ramasser sur la route
- Armes : missile guidé et mine (Espace)
- Chocs entre voitures : percuter un adversaire l'abîme, la jauge « État » à zéro = voiture détruite, retour en piste 3 secondes plus tard
- Classement en direct, mini-carte, fil des destructions, résultats en fin de course

## Lancer en local

```bash
npm install
npm run build
npm start
```

Puis ouvre http://localhost:3000

Pour développer avec rechargement automatique : `npm run dev` puis http://localhost:5173

## Mettre en ligne (Render, gratuit)

1. Pousse ce dossier sur GitHub
2. Sur render.com : New → Web Service → choisis le dépôt
3. Build command : `npm install && npm run build`
4. Start command : `npm start`
5. Render donne une adresse du type `https://turbo-clash.onrender.com` : c'est le lien du jeu

## Structure

- `shared/track.js` : le circuit (utilisé par le serveur et le jeu)
- `server/index.js` : salons, course, bonus, missiles, mines, dégâts
- `client/src/main.js` : physique de la voiture, réseau, caméra, interface
- `client/src/world.js` : décor (ville, route, barrières, lampadaires)
- `client/src/car.js` : modèle 3D de la voiture
- `client/src/fx.js` : explosions, étincelles, fumée, sons
