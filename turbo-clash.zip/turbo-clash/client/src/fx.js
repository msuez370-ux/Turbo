// Effets : étincelles, explosions, fumée, et sons générés.
import * as THREE from 'three';

const MAX = 3000;

export class Particles {
  constructor(scene) {
    this.pos = new Float32Array(MAX * 3);
    this.col = new Float32Array(MAX * 3);
    this.size = new Float32Array(MAX);
    this.vel = new Float32Array(MAX * 3);
    this.life = new Float32Array(MAX);
    this.maxLife = new Float32Array(MAX);
    this.base = new Float32Array(MAX * 3);
    this.grav = new Float32Array(MAX);
    this.next = 0;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    const m = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true,
      vertexShader: 'attribute float size; varying vec3 vC; void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = size * (300.0 / -mv.z); gl_Position = projectionMatrix * mv; }',
      fragmentShader: 'varying vec3 vC; void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; gl_FragColor = vec4(vC, 1.0) * smoothstep(0.5, 0.0, d); }',
    });
    this.points = new THREE.Points(g, m);
    this.points.frustumCulled = false;
    scene.add(this.points);
  }

  emit(x, y, z, vx, vy, vz, r, g, b, life, size, gravity = 9) {
    const i = this.next; this.next = (this.next + 1) % MAX;
    this.pos.set([x, y, z], i * 3);
    this.vel.set([vx, vy, vz], i * 3);
    this.base.set([r, g, b], i * 3);
    this.life[i] = this.maxLife[i] = life;
    this.size[i] = size;
    this.grav[i] = gravity;
  }

  sparks(x, y, z, n = 12) {
    for (let k = 0; k < n; k++) this.emit(x, y, z, (Math.random() - 0.5) * 18, Math.random() * 8, (Math.random() - 0.5) * 18, 1, 0.75, 0.3, 0.4 + Math.random() * 0.3, 0.35);
  }

  explosion(x, z, big = true) {
    const n = big ? 220 : 90;
    for (let k = 0; k < n; k++) {
      const a = Math.random() * Math.PI * 2, s = (big ? 22 : 12) * Math.random();
      const hot = Math.random();
      this.emit(x, 1 + Math.random(), z, Math.cos(a) * s, Math.random() * (big ? 20 : 10), Math.sin(a) * s,
        1, 0.35 + hot * 0.5, hot * 0.2, 0.6 + Math.random() * 0.9, big ? 1.6 : 1.0, 6);
    }
    for (let k = 0; k < (big ? 60 : 20); k++) {
      this.emit(x + (Math.random() - 0.5) * 3, 1.5, z + (Math.random() - 0.5) * 3, (Math.random() - 0.5) * 4, 3 + Math.random() * 4, (Math.random() - 0.5) * 4,
        0.25, 0.22, 0.25, 1.5 + Math.random() * 1.5, 3.2, -1);
    }
  }

  nitroTrail(x, y, z) {
    this.emit(x, y, z, (Math.random() - 0.5), Math.random(), (Math.random() - 0.5), 0.3, 0.75, 1, 0.25, 0.7, 0);
  }

  smoke(x, y, z) {
    this.emit(x, y, z, (Math.random() - 0.5) * 2, 2 + Math.random() * 2, (Math.random() - 0.5) * 2, 0.12, 0.12, 0.14, 1.2, 2.2, -1);
  }

  update(dt) {
    for (let i = 0; i < MAX; i++) {
      if (this.life[i] <= 0) { this.size[i] = 0; continue; }
      this.life[i] -= dt;
      const k = Math.max(0, this.life[i] / this.maxLife[i]);
      const j = i * 3;
      this.vel[j + 1] -= this.grav[i] * dt;
      this.pos[j] += this.vel[j] * dt;
      this.pos[j + 1] = Math.max(0.05, this.pos[j + 1] + this.vel[j + 1] * dt);
      this.pos[j + 2] += this.vel[j + 2] * dt;
      this.col[j] = this.base[j] * k; this.col[j + 1] = this.base[j + 1] * k; this.col[j + 2] = this.base[j + 2] * k;
    }
    const g = this.points.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.color.needsUpdate = true;
    g.attributes.size.needsUpdate = true;
  }
}

// Son du moteur et des explosions (généré, aucun fichier audio)
export class Sound {
  constructor() { this.ctx = null; }

  start() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const c = this.ctx;
      this.master = c.createGain(); this.master.gain.value = 0.35; this.master.connect(c.destination);
      this.osc = c.createOscillator(); this.osc.type = 'sawtooth';
      this.osc2 = c.createOscillator(); this.osc2.type = 'square';
      this.filter = c.createBiquadFilter(); this.filter.type = 'lowpass'; this.filter.frequency.value = 600;
      this.eng = c.createGain(); this.eng.gain.value = 0.12;
      const g2 = c.createGain(); g2.gain.value = 0.4;
      this.osc.connect(this.filter); this.osc2.connect(g2); g2.connect(this.filter);
      this.filter.connect(this.eng); this.eng.connect(this.master);
      this.osc.start(); this.osc2.start();
    } catch { this.ctx = null; }
  }

  engine(speed, nitro) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    // simulation de rapports de boîte
    const gear = Math.min(5, Math.floor(speed / 18));
    const rpm = 0.35 + ((speed - gear * 18) / 18) * 0.65;
    const f = 45 + rpm * 90 + gear * 8;
    this.osc.frequency.setTargetAtTime(f, t, 0.05);
    this.osc2.frequency.setTargetAtTime(f * 0.5, t, 0.05);
    this.filter.frequency.setTargetAtTime(500 + speed * 18 + (nitro ? 1200 : 0), t, 0.08);
  }

  noise(duration, freq, vol) {
    if (!this.ctx) return;
    const c = this.ctx;
    const len = Math.floor(c.sampleRate * duration);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 2;
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq;
    const g = c.createGain(); g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start();
  }

  boom() { this.noise(1.2, 700, 1.4); }
  crash() { this.noise(0.25, 2500, 0.6); }
  pickup() {
    if (!this.ctx) return;
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.frequency.setValueAtTime(600, c.currentTime);
    o.frequency.exponentialRampToValueAtTime(1400, c.currentTime + 0.15);
    g.gain.setValueAtTime(0.25, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.2);
    o.connect(g); g.connect(this.master); o.start(); o.stop(c.currentTime + 0.2);
  }
}
