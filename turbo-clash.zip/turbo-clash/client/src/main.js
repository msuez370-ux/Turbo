// Turbo Clash — logique du jeu dans le navigateur.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { io } from 'socket.io-client';
import { samples, SAMPLES, TRACK_WIDTH, LAPS, nearestSample, gridSlot } from '../../shared/track.js';
import { buildWorld, drawTrackMinimap } from './world.js';
import { buildCar, nameTag } from './car.js';
import { Particles, Sound } from './fx.js';

const $ = (id) => document.getElementById(id);
const socket = io();
const sound = new Sound();

// ---------- Rendu 3D ----------
const canvas = $('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 2500);
const { sun } = buildWorld(scene);
const fx = new Particles(scene);

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.75, 0.45, 0.82);
composer.addPass(bloom);
composer.addPass(new OutputPass());

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  composer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();

const minimap = drawTrackMinimap();
const mm = $('minimap').getContext('2d');

// ---------- État du jeu ----------
const LOCAL = {
  x: 0, z: 0, h: 0, vx: 0, vz: 0, steer: 0,
  idx: SAMPLES - 12, lastIdx: SAMPLES - 12, lap: 0, passedHalf: false,
  nitro: 30, weapon: null, hp: 100, destroyed: false, finished: false,
  shake: 0, wheelSpin: 0, pendingPickups: new Map(), lastScrape: 0,
};
let myId = null;
let roomCode = null;
let hostId = null;
let mode = 'menu';           // menu | lobby | countdown | racing | done
let startAt = 0;
let clockOffset = 0;         // différence entre l'heure du serveur et la nôtre
let lobbyPlayers = [];
const cars = new Map();      // id -> { model, data, target, tag }
let pickupMeshes = [];
const projectiles = new Map();

// ---------- Commandes clavier ----------
const keys = {};
window.addEventListener('keydown', (e) => {
  if (document.activeElement?.tagName === 'INPUT') return;
  keys[e.code] = true;
  if (e.code === 'Space' && mode === 'racing') { e.preventDefault(); fire(); }
  if (e.code === 'KeyR' && mode === 'racing' && !LOCAL.destroyed) resetToTrack();
  if (['ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
const down = (...codes) => codes.some(c => keys[c]);

// ---------- Menu et salle d'attente ----------
const params = new URLSearchParams(location.search);
const savedName = localStorage.getItem('tc_name') || '';
$('name').value = savedName;
if (params.get('room')) {
  $('code').value = params.get('room').toUpperCase();
  $('btnCreate').classList.add('hidden');
  document.querySelector('.or').textContent = 'Tu as été invité à cette course';
}

function show(screen) {
  ['menu', 'lobby', 'results'].forEach(s => $(s).classList.toggle('hidden', s !== screen));
  $('hud').classList.toggle('hidden', !(mode === 'racing' || mode === 'countdown' || mode === 'done'));
}

function playerName() {
  const n = $('name').value.trim() || 'Pilote' + Math.floor(Math.random() * 100);
  localStorage.setItem('tc_name', n);
  return n;
}

function join(code) {
  sound.start();
  socket.emit('join', { code, name: playerName() }, (res) => {
    if (res.error) { $('menuError').textContent = res.error; return; }
    myId = res.id;
    roomCode = res.code;
    history.replaceState(null, '', '/?room=' + res.code);
    setupPickups(res.pickups);
    mode = 'lobby';
    show('lobby');
  });
}

$('btnCreate').onclick = () => {
  socket.emit('create', {}, (res) => join(res.code));
};
$('btnJoin').onclick = () => {
  const code = $('code').value.trim().toUpperCase();
  if (code.length < 5) { $('menuError').textContent = 'Entre le code à 5 caractères.'; return; }
  join(code);
};
$('btnCopy').onclick = async () => {
  try { await navigator.clipboard.writeText($('inviteLink').value); $('btnCopy').textContent = 'Copié ✓'; }
  catch { $('inviteLink').select(); }
  setTimeout(() => { $('btnCopy').textContent = 'Copier'; }, 1500);
};
$('btnMail').onclick = () => {
  const to = $('inviteEmail').value.trim();
  const me = localStorage.getItem('tc_name') || 'Un pilote';
  const subject = `${me} te défie sur Turbo Clash 🏁`;
  const body = `Salut !\n\n${me} t'invite à une course en ligne sur Turbo Clash.\nClique sur ce lien pour rejoindre (rien à installer) :\n\n${$('inviteLink').value}\n\nCode de la course : ${roomCode}\n\nPrépare ta nitro 🔥`;
  window.location.href = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
};
let ready = false;
$('btnReady').onclick = () => {
  ready = !ready;
  socket.emit('ready', ready);
  $('btnReady').classList.toggle('on', ready);
  $('btnReady').textContent = ready ? 'Prêt ✓' : 'Je suis prêt';
};
$('btnStart').onclick = () => socket.emit('start');

socket.on('lobby', (data) => {
  hostId = data.hostId;
  lobbyPlayers = data.players;
  $('lobbyCode').textContent = data.code;
  $('inviteLink').value = `${location.origin}/?room=${data.code}`;
  $('playerList').innerHTML = data.players.map(p => `
    <li><span class="dot" style="color:${p.color};background:${p.color}"></span>${escapeHtml(p.name)}
    ${p.id === data.hostId ? '<small>👑</small>' : ''}${p.id === myId ? '<small>(toi)</small>' : ''}
    <span class="st">${p.ready ? '✅ prêt' : '⏳ en attente'}</span></li>`).join('');
  const isHost = myId === data.hostId;
  $('btnStart').classList.toggle('hidden', !isHost);
  $('lobbyHint').textContent = isHost
    ? (data.players.length === 1 ? "Envoie le lien à un ami, ou lance seul pour t'entraîner." : 'Lance la course quand tout le monde est prêt.')
    : "L'hôte (👑) va lancer la course.";
  syncCars(data.players);
  if (data.state === 'lobby' && mode !== 'menu' && mode !== 'lobby') {
    mode = 'lobby';
    ready = false;
    $('btnReady').classList.remove('on');
    $('btnReady').textContent = 'Je suis prêt';
    show('lobby');
  }
});

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ---------- Voitures ----------
function syncCars(players) {
  const ids = new Set(players.map(p => p.id));
  for (const [id, c] of cars) {
    if (!ids.has(id)) { scene.remove(c.model.car); cars.delete(id); }
  }
  players.forEach(p => {
    if (!cars.has(p.id)) {
      const model = buildCar(p.color);
      if (p.id !== myId) model.car.add(nameTag(p.name, p.color));
      scene.add(model.car);
      cars.set(p.id, { model, data: p, x: 0, z: 0, h: 0, s: 0, tx: 0, tz: 0, th: 0, destroyed: false, lap: 0, idx: 0, nitro: false });
    } else {
      cars.get(p.id).data = p;
    }
  });
}

function placeOnGrid(slot) {
  const g = gridSlot(slot);
  Object.assign(LOCAL, {
    x: g.x, z: g.z, h: g.heading, vx: 0, vz: 0, steer: 0,
    idx: SAMPLES - 12 - Math.floor(slot / 2) * 10, lap: 0, passedHalf: false,
    nitro: 30, weapon: null, hp: 100, destroyed: false, finished: false,
  });
  LOCAL.lastIdx = LOCAL.idx;
  updateWeaponHud();
}

function resetToTrack() {
  const s = samples[LOCAL.idx];
  LOCAL.x = s.x; LOCAL.z = s.z;
  LOCAL.h = Math.atan2(s.tx, s.tz);
  LOCAL.vx = LOCAL.vz = 0;
}

// ---------- Bonus sur la route ----------
const nitroGeo = new THREE.OctahedronGeometry(1.1);
const nitroMat = new THREE.MeshStandardMaterial({ color: '#3d7bff', emissive: '#08d9d6', emissiveIntensity: 2.2, transparent: true, opacity: 0.9 });
const weaponGeo = new THREE.BoxGeometry(1.6, 1.6, 1.6);
const weaponMat = new THREE.MeshStandardMaterial({ color: '#ff2e63', emissive: '#ff6b3d', emissiveIntensity: 2.2 });

function setupPickups(list) {
  pickupMeshes.forEach(p => scene.remove(p.mesh));
  pickupMeshes = list.map(p => {
    const mesh = new THREE.Mesh(p.type === 'nitro' ? nitroGeo : weaponGeo, p.type === 'nitro' ? nitroMat : weaponMat);
    mesh.position.set(p.x, 1.4, p.z);
    mesh.visible = p.active !== false;
    scene.add(mesh);
    return { ...p, mesh, active: p.active !== false };
  });
}
socket.on('pickupState', ({ id, active }) => {
  const p = pickupMeshes[id];
  if (p) { p.active = active; p.mesh.visible = active; }
});
socket.on('gotNitro', (amount) => { LOCAL.nitro = Math.min(100, LOCAL.nitro + amount); sound.pickup(); flashCenter('+ NITRO', 700); });
socket.on('gotWeapon', (w) => {
  LOCAL.weapon = w;
  updateWeaponHud();
  if (w) { sound.pickup(); flashCenter(w === 'missile' ? '🚀 MISSILE' : '💣 MINE', 700); }
});

function updateWeaponHud() {
  $('hudWeapon').textContent = LOCAL.weapon === 'missile' ? '🚀 Missile' : LOCAL.weapon === 'mine' ? '💣 Mine' : '—';
}

function fire() {
  if (!LOCAL.weapon || LOCAL.destroyed) return;
  socket.emit('fire');
}

// ---------- Missiles et mines ----------
const missileGeo = new THREE.CylinderGeometry(0.22, 0.22, 1.8, 8);
missileGeo.rotateX(Math.PI / 2);
const missileMat = new THREE.MeshStandardMaterial({ color: '#dddddd', emissive: '#ff6b3d', emissiveIntensity: 1.2 });
const mineGeo = new THREE.SphereGeometry(0.9, 16, 8);
mineGeo.scale(1, 0.45, 1);
const mineMat = new THREE.MeshStandardMaterial({ color: '#222', emissive: '#ff1030', emissiveIntensity: 1 });

function syncProjectiles(list, dt) {
  const seen = new Set();
  list.forEach(([id, kind, x, z, h, armed]) => {
    seen.add(id);
    let p = projectiles.get(id);
    if (!p) {
      p = new THREE.Mesh(kind === 'missile' ? missileGeo : mineGeo, kind === 'missile' ? missileMat.clone() : mineMat.clone());
      p.userData.kind = kind;
      p.position.set(x, kind === 'missile' ? 1.2 : 0.3, z);
      scene.add(p);
      projectiles.set(id, p);
    }
    p.userData.tx = x; p.userData.tz = z; p.rotation.y = h; p.userData.armed = armed;
  });
  for (const [id, p] of projectiles) if (!seen.has(id)) { scene.remove(p); projectiles.delete(id); }
}

socket.on('boom', ({ x, z, kind }) => {
  fx.explosion(x, z, kind === 'missile');
  const d = Math.hypot(x - LOCAL.x, z - LOCAL.z);
  if (d < 80) { sound.boom(); LOCAL.shake = Math.max(LOCAL.shake, 1.2 * (1 - d / 80)); }
});

// ---------- Course ----------
socket.on('countdown', ({ startAt: s, serverNow, players }) => {
  clockOffset = serverNow - Date.now();
  startAt = s;
  syncCars(players);
  const me = players.find(p => p.id === myId);
  placeOnGrid(me ? me.slot : 0);
  for (const p of players) {
    const c = cars.get(p.id);
    const g = gridSlot(p.slot);
    if (!c) continue;
    c.destroyed = false;
    c.model.paint.color.set(p.color); c.model.glow.visible = true; c.model.body.rotation.z = 0;
    if (p.id !== myId) { c.x = c.tx = g.x; c.z = c.tz = g.z; c.h = c.th = g.heading; c.init = true; }
  }
  $('feed').innerHTML = '';
  mode = 'countdown';
  show(null);
});

socket.on('snap', (snap) => {
  for (const [id, x, z, h, s, lap, idx, destroyed, nitro, hp] of snap.p) {
    const c = cars.get(id);
    if (!c) continue;
    if (id === myId) { c.lap = lap; c.idx = idx; continue; }
    c.tx = x; c.tz = z; c.th = h; c.s = s; c.lap = lap; c.idx = idx; c.nitro = !!nitro; c.hp = hp;
    if (!c.init) { c.x = x; c.z = z; c.h = h; c.init = true; }
  }
  latestProjectiles = snap.pr;
});
let latestProjectiles = [];

socket.on('damaged', ({ hp }) => {
  LOCAL.hp = hp;
  $('wreckFlash').style.opacity = 0.8;
  setTimeout(() => { $('wreckFlash').style.opacity = 0; }, 180);
});

socket.on('bumped', ({ power, dx, dz, lift }) => {
  const l = Math.hypot(dx, dz) || 1;
  LOCAL.vx += dx / l * power * 0.55;
  LOCAL.vz += dz / l * power * 0.55;
  LOCAL.h += (Math.random() - 0.5) * (lift ? 1.2 : 0.35);
  LOCAL.shake = Math.max(LOCAL.shake, lift ? 1.4 : 0.7);
  sound.crash();
  fx.sparks(LOCAL.x, 1, LOCAL.z, 20);
});

socket.on('wrecked', ({ id, x, z }) => {
  fx.explosion(x, z, true);
  const d = Math.hypot(x - LOCAL.x, z - LOCAL.z);
  if (d < 100) sound.boom();
  const c = cars.get(id);
  if (c) { c.destroyed = true; c.model.paint.color.multiplyScalar(0.15); c.model.glow.visible = false; c.model.body.rotation.z = 0.5; }
  if (id === myId) {
    LOCAL.destroyed = true;
    LOCAL.shake = 2;
    flashCenter('DÉTRUIT', 2500, true);
  }
});

socket.on('respawned', ({ id }) => {
  const c = cars.get(id);
  if (c) { c.destroyed = false; c.model.paint.color.set(c.data.color); c.model.glow.visible = true; c.model.body.rotation.z = 0; }
  if (id === myId) {
    LOCAL.destroyed = false;
    LOCAL.hp = 100;
    resetToTrack();
  }
});

socket.on('feed', (text) => {
  const el = document.createElement('div');
  el.textContent = text;
  $('feed').prepend(el);
  setTimeout(() => el.remove(), 5000);
  while ($('feed').children.length > 5) $('feed').lastChild.remove();
});

socket.on('results', (rows) => {
  mode = 'done';
  $('resultTable').innerHTML = '<tr><th>#</th><th>Pilote</th><th>Temps</th><th>Destructions</th></tr>' + rows.map(r => `
    <tr><td>${r.rank === 1 ? '🏆' : r.rank}</td><td style="color:${r.color}">${escapeHtml(r.name)}</td>
    <td>${r.time != null ? fmtTime(r.time) : 'DNF'}</td><td>${r.takedowns} 💥</td></tr>`).join('');
  show('results');
  $('hud').classList.remove('hidden');
});

let centerTimer = null;
function flashCenter(text, ms, small = false) {
  const el = $('center');
  el.textContent = text;
  el.classList.toggle('small', small || text.length > 4);
  clearTimeout(centerTimer);
  centerTimer = setTimeout(() => { el.textContent = ''; }, ms);
}

function fmtTime(ms) {
  ms = Math.max(0, ms);
  const m = Math.floor(ms / 60000), s = Math.floor(ms / 1000) % 60, d = Math.floor(ms / 100) % 10;
  return `${m}:${String(s).padStart(2, '0')}.${d}`;
}

// ---------- Physique de la voiture ----------
const MAX_SPEED = 72;      // ≈ 260 km/h
const NITRO_SPEED = 98;    // ≈ 350 km/h
const CAR_RADIUS = 1.6;

function physics(dt) {
  const fx_ = Math.sin(LOCAL.h), fz = Math.cos(LOCAL.h);
  let fwd = LOCAL.vx * fx_ + LOCAL.vz * fz;          // vitesse vers l'avant
  let lat = LOCAL.vx * fz - LOCAL.vz * fx_;          // glisse latérale

  const canDrive = mode === 'racing' && !LOCAL.destroyed && !LOCAL.finished;
  const throttle = canDrive && down('ArrowUp', 'KeyW', 'KeyZ') ? 1 : 0;
  const brake = canDrive && down('ArrowDown', 'KeyS') ? 1 : 0;
  const steerIn = canDrive ? (down('ArrowLeft', 'KeyA', 'KeyQ') ? 1 : 0) - (down('ArrowRight', 'KeyD') ? 1 : 0) : 0;
  const nitroOn = canDrive && down('ShiftLeft', 'ShiftRight') && LOCAL.nitro > 0 && fwd > 5;
  LOCAL.nitroOn = nitroOn;

  if (nitroOn) LOCAL.nitro = Math.max(0, LOCAL.nitro - 26 * dt);
  else LOCAL.nitro = Math.min(100, LOCAL.nitro + 1.5 * dt); // recharge lente

  const top = nitroOn ? NITRO_SPEED : MAX_SPEED;
  if (throttle) fwd += (nitroOn ? 48 : 30) * (1 - Math.max(0, fwd) / top * 0.85) * dt;
  else if (nitroOn) fwd += 40 * dt;
  if (brake) fwd -= (fwd > 0 ? 55 : 18) * dt;
  if (fwd > top) fwd -= (fwd - top) * 2 * dt;
  fwd = Math.max(-18, fwd);
  fwd -= fwd * 0.12 * dt + Math.sign(fwd) * 2 * dt * (throttle ? 0 : 1); // frottements
  if (!throttle && !brake && Math.abs(fwd) < 0.5) fwd = 0;

  // Direction : plus dure à haute vitesse, glisse en virage serré
  LOCAL.steer += (steerIn - LOCAL.steer) * Math.min(1, 8 * dt);
  const speedFactor = Math.min(1, Math.abs(fwd) / 12);
  const turn = LOCAL.steer * 2.1 * speedFactor * (1 - Math.min(Math.abs(fwd), 100) / 100 * 0.45);
  LOCAL.h += turn * Math.sign(fwd || 1) * dt;
  const drifting = Math.abs(LOCAL.steer) > 0.6 && Math.abs(fwd) > 45;
  const grip = drifting ? 3 : 9;
  lat *= Math.exp(-grip * dt);

  const nfx = Math.sin(LOCAL.h), nfz = Math.cos(LOCAL.h);
  LOCAL.vx = nfx * fwd + nfz * lat;
  LOCAL.vz = nfz * fwd - nfx * lat;
  LOCAL.x += LOCAL.vx * dt;
  LOCAL.z += LOCAL.vz * dt;
  LOCAL.speed = fwd;
  LOCAL.drifting = drifting;

  // Barrières
  LOCAL.idx = nearestSample(LOCAL.x, LOCAL.z, LOCAL.idx);
  const s = samples[LOCAL.idx];
  const off = (LOCAL.x - s.x) * s.nx + (LOCAL.z - s.z) * s.nz;
  const limit = TRACK_WIDTH / 2 + 2.2 - 1.1;
  if (Math.abs(off) > limit) {
    const sign = Math.sign(off);
    LOCAL.x -= s.nx * (off - sign * limit);
    LOCAL.z -= s.nz * (off - sign * limit);
    const vn = LOCAL.vx * s.nx + LOCAL.vz * s.nz;
    if (vn * sign > 0) {
      LOCAL.vx -= s.nx * vn * 1.4;
      LOCAL.vz -= s.nz * vn * 1.4;
      LOCAL.vx *= 0.93; LOCAL.vz *= 0.93;
      if (Math.abs(vn) > 6) { LOCAL.shake = Math.max(LOCAL.shake, Math.min(1, Math.abs(vn) / 30)); sound.crash(); }
    }
    const now = performance.now();
    if (now - LOCAL.lastScrape > 40 && Math.abs(fwd) > 10) {
      LOCAL.lastScrape = now;
      fx.sparks(LOCAL.x + s.nx * sign * 1.1, 0.6, LOCAL.z + s.nz * sign * 1.1, 4);
    }
  }

  // Chocs avec les autres voitures
  for (const [id, c] of cars) {
    if (id === myId || c.destroyed || !c.init) continue;
    const dx = c.x - LOCAL.x, dz = c.z - LOCAL.z;
    const d = Math.hypot(dx, dz);
    if (d > CAR_RADIUS * 2 || d < 0.001) continue;
    const nx = dx / d, nz = dz / d;
    const overlap = CAR_RADIUS * 2 - d;
    LOCAL.x -= nx * overlap * 0.6;
    LOCAL.z -= nz * overlap * 0.6;
    const myN = LOCAL.vx * nx + LOCAL.vz * nz;
    const theirN = Math.sin(c.h) * c.s * nx + Math.cos(c.h) * c.s * nz;
    const closing = myN - theirN;
    if (closing > 3) {
      LOCAL.vx -= nx * closing * 0.6;
      LOCAL.vz -= nz * closing * 0.6;
      fx.sparks(LOCAL.x + nx * CAR_RADIUS, 1, LOCAL.z + nz * CAR_RADIUS, 18);
      sound.crash();
      LOCAL.shake = Math.max(LOCAL.shake, Math.min(1.2, closing / 25));
      if (mode === 'racing' && closing > 6) socket.emit('ram', { target: id, power: closing });
    }
  }

  // Ramassage des bonus
  if (mode === 'racing' && !LOCAL.destroyed) {
    const now = performance.now();
    for (const p of pickupMeshes) {
      if (!p.active) continue;
      if ((p.x - LOCAL.x) ** 2 + (p.z - LOCAL.z) ** 2 < 3.6 ** 2) {
        if ((LOCAL.pendingPickups.get(p.id) || 0) > now) continue;
        LOCAL.pendingPickups.set(p.id, now + 1000);
        socket.emit('pickup', p.id);
      }
    }
  }

  // Tours de circuit
  const i = LOCAL.idx;
  if (i > SAMPLES * 0.45 && i < SAMPLES * 0.55) LOCAL.passedHalf = true;
  if (LOCAL.lastIdx > SAMPLES * 0.9 && i < SAMPLES * 0.1 && LOCAL.passedHalf && mode === 'racing') {
    LOCAL.lap++;
    LOCAL.passedHalf = false;
    socket.emit('lapDone', { lap: LOCAL.lap });
    if (LOCAL.lap >= LAPS) { LOCAL.finished = true; flashCenter('ARRIVÉE !', 3000, true); }
    else flashCenter(LOCAL.lap === LAPS - 1 ? 'DERNIER TOUR' : `TOUR ${LOCAL.lap + 1}`, 1500, true);
  }
  LOCAL.lastIdx = i;
}

// Progression dans le tour (négative tant qu'on est derrière la ligne de départ)
function progressInLap() {
  return LOCAL.idx > SAMPLES / 2 && !LOCAL.passedHalf ? LOCAL.idx - SAMPLES : LOCAL.idx;
}

// ---------- Boucle principale ----------
const clock = new THREE.Clock();
let sendTimer = 0;
const camPos = new THREE.Vector3(0, 30, -60);
const camLook = new THREE.Vector3();
let t = 0;

function updateCarModel(model, x, z, h, speed, steer, nitro, dt, lean = 0) {
  model.car.position.set(x, 0, z);
  model.car.rotation.y = h;
  model.body.rotation.x = THREE.MathUtils.lerp(model.body.rotation.x, -Math.min(0.04, Math.max(-0.04, (speed - (model.lastSpeed || 0)) * 0.02)), 0.2);
  model.body.rotation.z = THREE.MathUtils.lerp(model.body.rotation.z, lean, 0.15);
  model.lastSpeed = speed;
  model.spin = (model.spin || 0) + speed * dt / 0.42;
  model.wheels.forEach(w => {
    w.wheel.rotation.x = model.spin;
    if (w.front) w.pivot.rotation.y = steer * 0.45;
  });
  model.flames.forEach(f => {
    f.visible = nitro;
    if (nitro) f.scale.set(1, 0.7 + Math.random() * 0.6, 1);
  });
}

function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, clock.getDelta());
  t += dt;
  const now = Date.now() + clockOffset;

  // Compte à rebours
  if (mode === 'countdown') {
    const left = Math.ceil((startAt - now) / 1000);
    $('center').classList.remove('small');
    if (left > 0) $('center').textContent = left <= 3 ? left : '';
    else { mode = 'racing'; flashCenter('GO !', 900); }
  }

  if (mode === 'racing' || mode === 'countdown' || mode === 'done') {
    physics(dt);

    // Envoi de la position 20 fois par seconde
    sendTimer += dt;
    if (sendTimer > 0.05) {
      sendTimer = 0;
      socket.emit('state', { x: LOCAL.x, z: LOCAL.z, h: LOCAL.h, s: LOCAL.speed || 0, lap: LOCAL.lap, idx: progressInLap(), n: LOCAL.nitroOn ? 1 : 0 });
    }

    // Ma voiture
    const mine = cars.get(myId);
    if (mine) {
      updateCarModel(mine.model, LOCAL.x, LOCAL.z, LOCAL.h, LOCAL.speed || 0, LOCAL.steer, LOCAL.nitroOn, dt, LOCAL.drifting ? -LOCAL.steer * 0.06 : 0);
      if (LOCAL.nitroOn) {
        const bx = LOCAL.x - Math.sin(LOCAL.h) * 3, bz = LOCAL.z - Math.cos(LOCAL.h) * 3;
        fx.nitroTrail(bx, 0.6, bz);
      }
      if (LOCAL.drifting) fx.smoke(LOCAL.x - Math.sin(LOCAL.h) * 1.5, 0.3, LOCAL.z - Math.cos(LOCAL.h) * 1.5);
      if (LOCAL.destroyed && Math.random() < 0.5) fx.smoke(LOCAL.x, 1.2, LOCAL.z);
      if (LOCAL.hp < 35 && !LOCAL.destroyed && Math.random() < 0.3) fx.smoke(LOCAL.x + Math.sin(LOCAL.h) * 1.8, 1.1, LOCAL.z + Math.cos(LOCAL.h) * 1.8);
    }

    // Voitures des autres (mouvement lissé)
    const k = 1 - Math.exp(-12 * dt);
    for (const [id, c] of cars) {
      if (id === myId) continue;
      c.x += (c.tx - c.x) * k;
      c.z += (c.tz - c.z) * k;
      let dh = c.th - c.h;
      dh = Math.atan2(Math.sin(dh), Math.cos(dh));
      c.h += dh * k;
      updateCarModel(c.model, c.x, c.z, c.h, c.s, THREE.MathUtils.clamp(dh * 4, -1, 1), c.nitro && !c.destroyed, dt);
      if (c.nitro && !c.destroyed) fx.nitroTrail(c.x - Math.sin(c.h) * 3, 0.6, c.z - Math.cos(c.h) * 3);
      if (c.destroyed && Math.random() < 0.4) fx.smoke(c.x, 1.2, c.z);
    }

    // Projectiles
    syncProjectiles(latestProjectiles, dt);
    for (const p of projectiles.values()) {
      p.position.x += (p.userData.tx - p.position.x) * k;
      p.position.z += (p.userData.tz - p.position.z) * k;
      if (p.userData.kind === 'missile') fx.emit(p.position.x, 1.2, p.position.z, 0, 0.5, 0, 1, 0.5, 0.15, 0.3, 0.8, 0);
      else p.material.emissiveIntensity = p.userData.armed ? (Math.sin(t * 12) > 0 ? 3 : 0.3) : 0.3;
    }

    // Caméra de poursuite
    const spd = Math.abs(LOCAL.speed || 0);
    const fxh = Math.sin(LOCAL.h), fzh = Math.cos(LOCAL.h);
    const back = 8.5 + spd * 0.03;
    const desired = new THREE.Vector3(LOCAL.x - fxh * back, 3.4 + spd * 0.01, LOCAL.z - fzh * back);
    camPos.lerp(desired, 1 - Math.exp(-(mode === 'countdown' ? 3 : 7) * dt));
    camLook.set(LOCAL.x + fxh * 6, 1.3, LOCAL.z + fzh * 6);
    camera.position.copy(camPos);
    if (LOCAL.shake > 0) {
      camera.position.x += (Math.random() - 0.5) * LOCAL.shake;
      camera.position.y += (Math.random() - 0.5) * LOCAL.shake * 0.6;
      LOCAL.shake = Math.max(0, LOCAL.shake - dt * 2.5);
    }
    camera.lookAt(camLook);
    const targetFov = 68 + spd * 0.16 + (LOCAL.nitroOn ? 10 : 0);
    camera.fov += (targetFov - camera.fov) * Math.min(1, 4 * dt);
    camera.updateProjectionMatrix();

    // Ombres qui suivent le joueur
    sun.position.set(LOCAL.x - 60, 120, LOCAL.z + 40);
    sun.target.position.set(LOCAL.x, 0, LOCAL.z);

    sound.engine(spd, LOCAL.nitroOn);
    updateHud(now);
  } else {
    // Caméra qui tourne autour du circuit dans les menus
    const a = t * 0.06;
    camera.position.set(Math.cos(a) * 420 + 50, 160, Math.sin(a) * 420 + 150);
    camera.lookAt(50, 0, 150);
    if (camera.fov !== 60) { camera.fov = 60; camera.updateProjectionMatrix(); }
  }

  // Bonus qui tournent
  pickupMeshes.forEach((p, i) => {
    p.mesh.rotation.y = t * 2 + i;
    p.mesh.position.y = 1.4 + Math.sin(t * 3 + i) * 0.25;
  });

  fx.update(dt);
  composer.render();
}

function updateHud(now) {
  const kmh = Math.round(Math.abs(LOCAL.speed || 0) * 3.6);
  $('hudSpeed').textContent = kmh;
  $('hudLap').textContent = `${Math.min(LOCAL.lap + 1, LAPS)}/${LAPS}`;
  $('hudTime').textContent = mode === 'countdown' ? '0:00.0' : fmtTime(now - startAt);
  $('hpBar').style.width = LOCAL.hp + '%';
  $('hpBar').style.background = LOCAL.hp < 35 ? 'linear-gradient(90deg,#ff2e63,#ff6b3d)' : '';
  $('nitroBar').style.width = LOCAL.nitro + '%';

  // Classement
  const ranking = [...cars.entries()].map(([id, c]) => {
    const prog = id === myId ? LOCAL.lap * SAMPLES + progressInLap() : c.lap * SAMPLES + c.idx;
    return { id, name: c.data.name, color: c.data.color, prog, fin: c.data.finished };
  }).sort((a, b) => b.prog - a.prog);
  const pos = ranking.findIndex(r => r.id === myId) + 1;
  $('hudPos').textContent = `${pos}/${ranking.length}`;
  $('board').innerHTML = ranking.map((r, i) =>
    `<div class="${r.id === myId ? 'me' : ''}">${i + 1}. <i style="background:${r.color}"></i>${escapeHtml(r.name)}</div>`).join('');

  // Mini-carte
  mm.clearRect(0, 0, 200, 200);
  mm.drawImage(minimap.canvas, 0, 0);
  for (const [id, c] of cars) {
    const [a, b] = minimap.project(id === myId ? LOCAL.x : c.x, id === myId ? LOCAL.z : c.z);
    mm.beginPath();
    mm.arc(a, b, id === myId ? 7 : 5, 0, Math.PI * 2);
    mm.fillStyle = c.data.color;
    mm.fill();
    if (id === myId) { mm.strokeStyle = '#fff'; mm.lineWidth = 2; mm.stroke(); }
  }
}

show('menu');
loop();
