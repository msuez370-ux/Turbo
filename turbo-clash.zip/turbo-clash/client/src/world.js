// Décor : ville de nuit, route, bordures, barrières, lampadaires, immeubles.
import * as THREE from 'three';
import { samples, SAMPLES, TRACK_WIDTH, nearestSample } from '../../shared/track.js';

function canvasTexture(w, h, draw, repeat = [1, 1]) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat[0], repeat[1]);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

// Ruban qui suit le circuit entre deux décalages latéraux
function ribbon(offA, offB, y, uScale) {
  const pos = [], uv = [], idx = [];
  let dist = 0;
  for (let i = 0; i <= SAMPLES; i++) {
    const s = samples[i % SAMPLES];
    if (i > 0) { const p = samples[i - 1]; dist += Math.hypot(s.x - p.x, s.z - p.z); }
    pos.push(s.x + s.nx * offA, y, s.z + s.nz * offA, s.x + s.nx * offB, y, s.z + s.nz * offB);
    uv.push(0, dist / uScale, 1, dist / uScale);
    if (i < SAMPLES) { const a = i * 2; idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

// Mur vertical qui suit le circuit
function wall(off, h) {
  const pos = [], uv = [], idx = [];
  let dist = 0;
  for (let i = 0; i <= SAMPLES; i++) {
    const s = samples[i % SAMPLES];
    if (i > 0) { const p = samples[i - 1]; dist += Math.hypot(s.x - p.x, s.z - p.z); }
    const x = s.x + s.nx * off, z = s.z + s.nz * off;
    pos.push(x, 0, z, x, h, z);
    uv.push(dist / 8, 0, dist / 8, 1);
    if (i < SAMPLES) { const a = i * 2; idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export function buildWorld(scene) {
  scene.background = new THREE.Color('#090b1a');
  scene.fog = new THREE.FogExp2('#0d1028', 0.0034);

  // Ciel dégradé
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(1500, 32, 16),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: {},
      vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: 'varying vec3 vP; void main(){ float h = vP.y; vec3 top = vec3(0.02,0.02,0.08); vec3 mid = vec3(0.18,0.05,0.25); vec3 low = vec3(0.95,0.32,0.25); vec3 c = h > 0.08 ? mix(mid, top, smoothstep(0.08,0.6,h)) : mix(low, mid, smoothstep(-0.05,0.08,h)); gl_FragColor = vec4(c,1.0); }',
    }),
  );
  scene.add(sky);

  // Lumières
  scene.add(new THREE.HemisphereLight('#7f8cff', '#2a1a30', 0.9));
  const sun = new THREE.DirectionalLight('#ffb38a', 1.6);
  sun.position.set(-120, 160, 80);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const sc = sun.shadow.camera;
  sc.left = -70; sc.right = 70; sc.top = 70; sc.bottom = -70; sc.near = 10; sc.far = 400;
  sun.shadow.bias = -0.0005;
  scene.add(sun, sun.target);

  // Sol
  const groundTex = canvasTexture(256, 256, (g, w, h) => {
    g.fillStyle = '#121620'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 4000; i++) { g.fillStyle = `rgba(${40 + Math.random() * 30},${50 + Math.random() * 30},${60 + Math.random() * 30},0.25)`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
  }, [120, 120]);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.02;
  ground.receiveShadow = true;
  scene.add(ground);

  // Route
  const roadTex = canvasTexture(512, 512, (g, w, h) => {
    g.fillStyle = '#3d3f48'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) { const v = 50 + Math.random() * 45; g.fillStyle = `rgba(${v},${v},${v + 4},0.5)`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
    g.fillStyle = 'rgba(255,255,255,0.85)';
    g.fillRect(10, 0, 8, h); g.fillRect(w - 18, 0, 8, h);       // lignes de bord
    g.fillStyle = 'rgba(255,255,255,0.7)';
    g.fillRect(w / 3 - 3, 0, 6, h / 2); g.fillRect(2 * w / 3 - 3, 0, 6, h / 2); // pointillés
    g.fillStyle = 'rgba(0,0,0,0.15)';
    for (let i = 0; i < 6; i++) g.fillRect(w * (0.2 + Math.random() * 0.6), 0, 20 + Math.random() * 20, h); // traces de pneus
  });
  const road = new THREE.Mesh(ribbon(-TRACK_WIDTH / 2, TRACK_WIDTH / 2, 0.02, 24),
    new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.38, metalness: 0.25 }));
  road.receiveShadow = true;
  scene.add(road);

  // Vibreurs rouge et blanc
  const curbTex = canvasTexture(64, 128, (g, w, h) => {
    g.fillStyle = '#ff2e45'; g.fillRect(0, 0, w, h / 2);
    g.fillStyle = '#f5f5f5'; g.fillRect(0, h / 2, w, h / 2);
  });
  const curbMat = new THREE.MeshStandardMaterial({ map: curbTex, roughness: 0.6 });
  scene.add(new THREE.Mesh(ribbon(-TRACK_WIDTH / 2 - 1.6, -TRACK_WIDTH / 2, 0.04, 3), curbMat));
  scene.add(new THREE.Mesh(ribbon(TRACK_WIDTH / 2, TRACK_WIDTH / 2 + 1.6, 0.04, 3), curbMat));

  // Barrières avec bande lumineuse
  const barrierTex = canvasTexture(128, 64, (g, w, h) => {
    g.fillStyle = '#1b1e2b'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#08d9d6'; g.fillRect(0, h * 0.35, w, h * 0.18);
    g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(0, 0, 3, h);
  });
  const barrierMat = new THREE.MeshStandardMaterial({ map: barrierTex, emissive: '#08d9d6', emissiveMap: barrierTex, emissiveIntensity: 0.9, side: THREE.DoubleSide, roughness: 0.5 });
  const edge = TRACK_WIDTH / 2 + 2.2;
  scene.add(new THREE.Mesh(wall(-edge, 1.3), barrierMat));
  scene.add(new THREE.Mesh(wall(edge, 1.3), barrierMat));

  // Ligne de départ en damier
  const checker = canvasTexture(256, 64, (g, w, h) => {
    const n = 16, m = 4, cw = w / n, ch = h / m;
    for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) { g.fillStyle = (i + j) % 2 ? '#111' : '#fff'; g.fillRect(i * cw, j * ch, cw, ch); }
  });
  const s0 = samples[0];
  const start = new THREE.Mesh(new THREE.PlaneGeometry(TRACK_WIDTH, 3), new THREE.MeshStandardMaterial({ map: checker, roughness: 0.6 }));
  start.rotation.x = -Math.PI / 2;
  start.rotation.z = Math.atan2(s0.tx, s0.tz);
  start.position.set(s0.x, 0.05, s0.z);
  scene.add(start);

  // Portique d'arrivée
  const gantry = new THREE.Group();
  const postMat = new THREE.MeshStandardMaterial({ color: '#222533', metalness: 0.7, roughness: 0.3 });
  const glow = new THREE.MeshStandardMaterial({ color: '#ff2e63', emissive: '#ff2e63', emissiveIntensity: 2.5 });
  [-1, 1].forEach(side => {
    const post = new THREE.Mesh(new THREE.BoxGeometry(1, 9, 1), postMat);
    post.position.set(side * (TRACK_WIDTH / 2 + 2.5), 4.5, 0);
    post.castShadow = true;
    gantry.add(post);
  });
  const beam = new THREE.Mesh(new THREE.BoxGeometry(TRACK_WIDTH + 6, 1.6, 1), postMat);
  beam.position.y = 9;
  gantry.add(beam);
  const strip = new THREE.Mesh(new THREE.BoxGeometry(TRACK_WIDTH + 6, 0.25, 1.1), glow);
  strip.position.y = 8.3;
  gantry.add(strip);
  gantry.position.set(s0.x, 0, s0.z);
  gantry.rotation.y = Math.atan2(-s0.nz, s0.nx);
  scene.add(gantry);

  // Lampadaires
  const lampCount = Math.floor(SAMPLES / 30);
  const poles = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.15, 0.2, 9, 6), postMat, lampCount);
  const heads = new THREE.InstancedMesh(new THREE.BoxGeometry(2.4, 0.3, 0.6), new THREE.MeshStandardMaterial({ color: '#fff2d0', emissive: '#ffd9a0', emissiveIntensity: 3 }), lampCount);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
  for (let k = 0; k < lampCount; k++) {
    const s = samples[k * 30];
    const side = k % 2 ? 1 : -1;
    const off = side * (TRACK_WIDTH / 2 + 3.4);
    m.makeTranslation(s.x + s.nx * off, 4.5, s.z + s.nz * off);
    poles.setMatrixAt(k, m);
    e.set(0, Math.atan2(s.nx, s.nz) + Math.PI / 2, 0); q.setFromEuler(e);
    m.compose(new THREE.Vector3(s.x + s.nx * (off - side * 1.1), 9, s.z + s.nz * (off - side * 1.1)), q, new THREE.Vector3(1, 1, 1));
    heads.setMatrixAt(k, m);
  }
  scene.add(poles, heads);

  // Immeubles avec fenêtres éclairées
  const winTex = canvasTexture(128, 256, (g, w, h) => {
    g.fillStyle = '#0b0d16'; g.fillRect(0, 0, w, h);
    for (let y = 6; y < h; y += 14) for (let x = 6; x < w; x += 14) {
      const r = Math.random();
      g.fillStyle = r < 0.45 ? (r < 0.15 ? '#ffd27a' : r < 0.3 ? '#7ad7ff' : '#ff8ad8') : '#151826';
      g.fillRect(x, y, 8, 9);
    }
  });
  const buildingMat = new THREE.MeshStandardMaterial({ map: winTex, emissive: '#ffffff', emissiveMap: winTex, emissiveIntensity: 1.1, roughness: 0.8 });
  const B = 260;
  const buildings = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), buildingMat, B);
  let placed = 0, tries = 0;
  while (placed < B && tries < 6000) {
    tries++;
    const x = (Math.random() - 0.5) * 1200 + 50, z = (Math.random() - 0.5) * 1100 + 150;
    const s = samples[nearestSample(x, z)];
    const w = 14 + Math.random() * 26, d = 14 + Math.random() * 26;
    if (Math.hypot(s.x - x, s.z - z) < TRACK_WIDTH / 2 + 10 + Math.max(w, d) * 0.75) continue;
    const h = 15 + Math.random() ** 2 * 140;
    m.compose(new THREE.Vector3(x, h / 2, z), q.identity(), new THREE.Vector3(w, h, d));
    buildings.setMatrixAt(placed++, m);
  }
  buildings.count = placed;
  buildings.castShadow = true;
  buildings.receiveShadow = true;
  scene.add(buildings);

  return { sun };
}

// Texture pour la mini-carte
export function drawTrackMinimap() {
  const c = document.createElement('canvas');
  c.width = c.height = 200;
  const g = c.getContext('2d');
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  samples.forEach(s => { minX = Math.min(minX, s.x); maxX = Math.max(maxX, s.x); minZ = Math.min(minZ, s.z); maxZ = Math.max(maxZ, s.z); });
  const scale = 170 / Math.max(maxX - minX, maxZ - minZ);
  const ox = 100 - (minX + maxX) / 2 * scale, oz = 100 - (minZ + maxZ) / 2 * scale;
  const project = (x, z) => [ox + x * scale, oz + z * scale];
  g.lineJoin = 'round';
  g.beginPath();
  samples.forEach((s, i) => { const [a, b] = project(s.x, s.z); i ? g.lineTo(a, b) : g.moveTo(a, b); });
  g.closePath();
  g.strokeStyle = 'rgba(8,10,20,0.85)'; g.lineWidth = 12; g.stroke();
  g.strokeStyle = 'rgba(8,217,214,0.7)'; g.lineWidth = 4; g.stroke();
  return { canvas: c, project };
}
