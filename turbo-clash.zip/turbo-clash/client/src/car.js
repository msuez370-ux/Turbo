// Voiture de sport construite en 3D (orientée vers +Z).
import * as THREE from 'three';

function taperedBox(w, h, d, topW, topD, topShiftZ = 0) {
  const g = new THREE.BoxGeometry(w, h, d, 1, 1, 1);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    if (p.getY(i) > 0) {
      p.setX(i, p.getX(i) * topW / w);
      p.setZ(i, p.getZ(i) * topD / d + topShiftZ);
    }
  }
  g.computeVertexNormals();
  return g;
}

export function buildCar(color) {
  const car = new THREE.Group();
  const body = new THREE.Group();
  car.add(body);

  const paint = new THREE.MeshPhysicalMaterial({ color, metalness: 0.75, roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.08 });
  const dark = new THREE.MeshStandardMaterial({ color: '#0d0f14', metalness: 0.5, roughness: 0.5 });
  const glass = new THREE.MeshPhysicalMaterial({ color: '#0a1424', metalness: 0.9, roughness: 0.05, transparent: true, opacity: 0.85 });

  const chassis = new THREE.Mesh(taperedBox(2.1, 0.55, 4.6, 2.0, 4.3), paint);
  chassis.position.y = 0.6;
  const hood = new THREE.Mesh(taperedBox(2.0, 0.25, 4.2, 1.8, 3.6, 0.1), paint);
  hood.position.y = 1.0;
  const cabin = new THREE.Mesh(taperedBox(1.75, 0.6, 2.2, 1.35, 1.2, -0.25), glass);
  cabin.position.set(0, 1.42, -0.35);
  const skirt = new THREE.Mesh(new THREE.BoxGeometry(2.16, 0.18, 4.4), dark);
  skirt.position.y = 0.36;
  [chassis, hood, cabin, skirt].forEach(m => { m.castShadow = true; body.add(m); });

  // Aileron
  const wing = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 0.5), dark);
  wing.position.set(0, 1.55, -2.1);
  const wl = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.4, 0.3), dark);
  wl.position.set(-0.7, 1.32, -2.05);
  const wr = wl.clone(); wr.position.x = 0.7;
  body.add(wing, wl, wr);

  // Phares avant et arrière
  const head = new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#dff6ff', emissiveIntensity: 4 });
  const tail = new THREE.MeshStandardMaterial({ color: '#ff1030', emissive: '#ff1030', emissiveIntensity: 3 });
  [-0.7, 0.7].forEach(x => {
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.05), head); h.position.set(x, 0.85, 2.3); body.add(h);
    const t = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.12, 0.05), tail); t.position.set(x, 0.9, -2.31); body.add(t);
  });

  // Néon sous la voiture
  const gc = document.createElement('canvas'); gc.width = gc.height = 64;
  const gg = gc.getContext('2d');
  const grad = gg.createRadialGradient(32, 32, 2, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,0.9)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
  gg.fillStyle = grad; gg.fillRect(0, 0, 64, 64);
  const glowMat = new THREE.MeshBasicMaterial({ color, map: new THREE.CanvasTexture(gc), transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false });
  const glow = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 7), glowMat);
  glow.rotation.x = -Math.PI / 2;
  glow.position.y = 0.06;
  car.add(glow);

  // Roues
  const wheels = [];
  const tire = new THREE.MeshStandardMaterial({ color: '#111', roughness: 0.9 });
  const rim = new THREE.MeshStandardMaterial({ color: '#c8ccd6', metalness: 1, roughness: 0.25 });
  [[-1, 1.45], [1, 1.45], [-1, -1.45], [1, -1.45]].forEach(([sx, z]) => {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 1.0, 0.42, z);
    const wheel = new THREE.Group();
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.34, 20), tire);
    t.rotation.z = Math.PI / 2;
    const r = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.36, 10), rim);
    r.rotation.z = Math.PI / 2;
    t.castShadow = true;
    wheel.add(t, r);
    pivot.add(wheel);
    car.add(pivot);
    wheels.push({ pivot, wheel, front: z > 0 });
  });

  // Flammes de nitro
  const flameMat = new THREE.MeshBasicMaterial({ color: '#5fd8ff', transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
  const flames = [-0.5, 0.5].map(x => {
    const f = new THREE.Mesh(new THREE.ConeGeometry(0.18, 1.6, 10), flameMat);
    f.rotation.x = -Math.PI / 2;
    f.position.set(x, 0.55, -3.0);
    f.visible = false;
    car.add(f);
    return f;
  });

  return { car, body, wheels, flames, paint, glow };
}

// Étiquette avec le pseudo au-dessus d'une voiture
export function nameTag(name, color) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.font = 'bold 34px Rajdhani, sans-serif';
  g.textAlign = 'center';
  g.fillStyle = 'rgba(5,6,12,0.65)';
  g.fillRect(28, 8, 200, 48);
  g.fillStyle = color;
  g.fillRect(28, 52, 200, 4);
  g.fillStyle = '#fff';
  g.fillText(name, 128, 44);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
  s.scale.set(4, 1, 1);
  s.position.y = 3.2;
  s.renderOrder = 10;
  return s;
}
