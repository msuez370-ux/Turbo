// Circuit partagé entre le serveur et le navigateur.
// Une boucle fermée définie par des points de contrôle, lissée en courbe Catmull-Rom.

export const TRACK_WIDTH = 26;      // largeur de la route en mètres
export const LAPS = 3;              // nombre de tours
export const SAMPLES = 1200;        // précision du tracé

// Points de contrôle (x, z) en mètres
const CONTROL = [
  [0, 0], [180, -10], [320, 30], [400, 140], [380, 280],
  [260, 340], [140, 300], [60, 380], [-80, 420], [-220, 360],
  [-300, 230], [-240, 120], [-320, 20], [-260, -120], [-120, -90],
];

function catmull(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
}

function pointAt(u) {
  const n = CONTROL.length;
  const f = ((u % 1) + 1) % 1 * n;
  const i = Math.floor(f), t = f - i;
  const a = CONTROL[(i - 1 + n) % n], b = CONTROL[i], c = CONTROL[(i + 1) % n], d = CONTROL[(i + 2) % n];
  return { x: catmull(a[0], b[0], c[0], d[0], t), z: catmull(a[1], b[1], c[1], d[1], t) };
}

// Échantillons réguliers le long du circuit, avec direction (tx, tz) et normale (nx, nz)
export const samples = (() => {
  const out = [];
  for (let i = 0; i < SAMPLES; i++) out.push(pointAt(i / SAMPLES));
  for (let i = 0; i < SAMPLES; i++) {
    const a = out[(i - 1 + SAMPLES) % SAMPLES], b = out[(i + 1) % SAMPLES];
    let tx = b.x - a.x, tz = b.z - a.z;
    const l = Math.hypot(tx, tz) || 1;
    tx /= l; tz /= l;
    out[i].tx = tx; out[i].tz = tz;
    out[i].nx = -tz; out[i].nz = tx;
  }
  return out;
})();

// Échantillon le plus proche d'une position. `hint` accélère la recherche locale.
export function nearestSample(x, z, hint = -1) {
  let best = 0, bd = Infinity;
  if (hint >= 0) {
    for (let k = -40; k <= 40; k++) {
      const i = (hint + k + SAMPLES) % SAMPLES;
      const s = samples[i];
      const d = (s.x - x) ** 2 + (s.z - z) ** 2;
      if (d < bd) { bd = d; best = i; }
    }
    if (bd < (TRACK_WIDTH * 2) ** 2) return best;
  }
  for (let i = 0; i < SAMPLES; i++) {
    const s = samples[i];
    const d = (s.x - x) ** 2 + (s.z - z) ** 2;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

// Position de départ sur la grille (2 voitures par rangée, derrière la ligne)
export function gridSlot(slot) {
  const row = Math.floor(slot / 2), col = slot % 2;
  const s = samples[(SAMPLES - 12 - row * 10) % SAMPLES];
  const side = col === 0 ? -5 : 5;
  return { x: s.x + s.nx * side, z: s.z + s.nz * side, heading: Math.atan2(s.tx, s.tz) };
}

// Emplacements des bonus le long du circuit
export function pickupLayout() {
  const list = [];
  let id = 0;
  for (let i = 80; i < SAMPLES - 40; i += 110) {
    const s = samples[i];
    const lanes = [-8, 0, 8];
    lanes.forEach((off, k) => {
      // alternance nitro / arme
      const type = (Math.floor(i / 110) + k) % 3 === 0 ? 'weapon' : (k === 1 ? 'weapon' : 'nitro');
      list.push({ id: id++, type, x: s.x + s.nx * off, z: s.z + s.nz * off });
    });
  }
  return list;
}
